(() => {
  const $ = id => document.getElementById(id);

  // DOM elements
  const ipEl = $('ip'), connEl = $('conn'), alertsEl = $('alertsCount');
  const engineTemp = $('engineTemp'), engineHum = $('engineHum'), gasRaw = $('gasRaw');
  const oilLevel = $('oilLevel'), oilFill = $('oilFill'), alertBox = $('alertBox');
  const gpsCoords = $('gpsCoords'), gpsSats = $('gpsSats'), outerTemp = $('outerTemp'), outerHum = $('outerHum');
  const radarCanvas = $('radarCanvas'), radarAngleEl = $('radarAngle'), radarDistEl = $('radarDist'), radarTimeEl = $('radarTime');
  const autoRadar = $('autoRadar'), radarManual = $('radarManual'), radarManualVal = $('radarManualVal');
  const setRadarBtn = $('setRadarBtn'), centerRadarBtn = $('centerRadarBtn');
  const crane1 = $('crane1'), crane2 = $('crane2'), c1Val = $('c1Val'), c2Val = $('c2Val');
  const c1Load = $('c1Load'), c1Unload = $('c1Unload'), c2Load = $('c2Load'), c2Unload = $('c2Unload');
  const neoStatus = $('neoStatus'), buzzerStatus = $('buzzerStatus');
  const logEl = $('log'), refreshBtn = $('refreshBtn'), buzzerTest = $('buzzerTest'), clearLog = $('clearLog');

  // Canvas setup for HiDPI
  const ctx = radarCanvas.getContext('2d');
  function setupCanvas() {
    const ratio = window.devicePixelRatio || 1;
    const cssW = radarCanvas.clientWidth;
    const cssH = radarCanvas.clientHeight;
    radarCanvas.width = Math.floor(cssW * ratio);
    radarCanvas.height = Math.floor(cssH * ratio);
    radarCanvas.style.width = cssW + "px";
    radarCanvas.style.height = cssH + "px";
    ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
  }
  setupCanvas();
  window.addEventListener('resize', () => {
    setupCanvas();
    drawRadarEcho(currentAngle, currentDist);
  });

  // Radar state
  let lastData = null, sse = null, polling = null;
  let currentAngle = 90, currentDist = -1, currentMax = 350;

  // Sweep animation
  let sweepAngle = 0;
  let sweepDir = 1;
  let lastFrameTime = null;

  // History of echoes: array of { angle, dist, fade } entries
  const echoHistory = [];

  function updateEchoHistory(angle, dist, maxDistance) {
    if (typeof angle === 'number' && typeof dist === 'number' && dist > 0) {
      echoHistory.push({ angle, dist, maxDistance, fade: 1.0 });
    }
  }

  function drawRadarEcho(angle = 90, dist = -1) {
    // clear
    ctx.clearRect(0, 0, radarCanvas.width, radarCanvas.height);

    const ratio = window.devicePixelRatio || 1;
    const logicalW = radarCanvas.width / ratio;
    const logicalH = radarCanvas.height / ratio;
    const cx = logicalW / 2;
    const cy = logicalH * 0.92;
    const maxR = Math.min(cx - 24, logicalH - 44);

    ctx.save();

    // draw background arcs
    ctx.lineWidth = 1;
    for (let r = 1; r <= 3; r++) {
      ctx.beginPath();
      ctx.strokeStyle = `rgba(0,255,0,${0.1 * (4 - r)})`;  // green faint arcs
      ctx.arc(cx, cy, (r/3) * maxR, Math.PI, 0, false);
      ctx.stroke();
    }

    // radial lines every 30°
    for (let a = 0; a <= 180; a += 30) {
      const ra = Math.PI * (a / 180);
      ctx.beginPath();
      ctx.moveTo(cx, cy);
      ctx.lineTo(cx + Math.cos(ra)*maxR, cy - Math.sin(ra)*maxR);
      ctx.strokeStyle = 'rgba(0,200,0,0.1)';
      ctx.stroke();
    }

    // draw echo history (red lines)
    for (let i = echoHistory.length - 1; i >= 0; i--) {
      const e = echoHistory[i];
      if (e.fade <= 0) {
        echoHistory.splice(i, 1);
        continue;
      }
      const ra = Math.PI * (e.angle / 180);
      const capped = Math.min(e.dist, e.maxDistance || currentMax);
      const r = (capped / (e.maxDistance || currentMax)) * maxR;

      // draw line from center outward
      ctx.beginPath();
      ctx.moveTo(cx, cy);
      ctx.lineTo(cx + Math.cos(ra)*r, cy - Math.sin(ra)*r);
      ctx.strokeStyle = `rgba(255,50,50,${e.fade})`;
      ctx.lineWidth = 2;
      ctx.stroke();

      // fade
      e.fade -= 0.01;
    }

    // draw sweep line (green)
    const raSweep = Math.PI * (sweepAngle / 180);
    ctx.beginPath();
    ctx.moveTo(cx, cy);
    ctx.lineTo(cx + Math.cos(raSweep)*maxR, cy - Math.sin(raSweep)*maxR);
    ctx.strokeStyle = 'rgba(0,255,0,0.7)';
    ctx.lineWidth = 2;
    ctx.stroke();

    ctx.restore();
  }

  function animateSweep(timestamp) {
    if (lastFrameTime === null) lastFrameTime = timestamp;
    const delta = timestamp - lastFrameTime;
    lastFrameTime = timestamp;

    const speed = 60; // deg/s
    sweepAngle += sweepDir * (delta / 1000) * speed;
    if (sweepAngle >= 180) { sweepAngle = 180; sweepDir = -1; }
    if (sweepAngle <= 0) { sweepAngle = 0; sweepDir = 1; }

    if (autoRadar && autoRadar.checked) {
      drawRadarEcho(sweepAngle, -1);
    }

    requestAnimationFrame(animateSweep);
  }
  requestAnimationFrame(animateSweep);

  function safe(val, def='--') { return (val === null || val === undefined) ? def : val; }

  function updateFromJson(d) {
    lastData = d;

    if (d.engine_room) {
      engineTemp.textContent = safe(d.engine_room.temp_c) + ' °C';
      engineHum.textContent = safe(d.engine_room.hum_pct) + ' %';
      gasRaw.textContent = safe(d.engine_room.gas_raw);
      const oilPct = d.engine_room.oil_level_pct;
      if (oilPct === -1 || oilPct === null || oilPct === undefined) {
        oilLevel.textContent = 'No fuel';
        oilFill.style.height = '0%';
      } else {
        oilLevel.textContent = oilPct + '%';
        oilFill.style.height = Math.max(0, Math.min(100, oilPct)) + '%';
      }
    }

    if (d.gps) {
      gpsCoords.textContent = (d.gps.lat ?? '--') + ', ' + (d.gps.lon ?? '--');
      gpsSats.textContent = (d.gps.sats ?? '--') + ' / ' + (d.gps.time ?? '--');
    }
    if (d.outer) {
      outerTemp.textContent = (d.outer.temp_c ?? '--') + ' °C';
      outerHum.textContent = (d.outer.hum_pct ?? '--') + ' %';
    }

    if (d.radar) {
      currentAngle = d.radar.angle;
      currentDist = d.radar.distance_cm;
      currentMax = d.radar.max_distance || 350;

      radarAngleEl.textContent = safe(currentAngle);
      radarDistEl.textContent = safe(currentDist);
      radarTimeEl.textContent = new Date().toLocaleTimeString();

      updateEchoHistory(currentAngle, currentDist, currentMax);

      drawRadarEcho(currentAngle, currentDist);
    } else {
      drawRadarEcho(90, -1);
    }

    if (d.alerts) {
      const any = d.alerts.any ? true : false;
      alertsEl.textContent = any ? '1' : '0';
      alertBox.textContent = any ? '⚠ ACTIVE ALERTS' : 'No active alerts';
      connEl.textContent = 'Online';
      if (any) {
        neoStatus.style.background = 'linear-gradient(90deg,#ff7b7b,#ff9b6b)';
        buzzerStatus.style.background = 'linear-gradient(90deg,#ffb5b5,#ff6b6b)';
      } else {
        neoStatus.style.background = 'linear-gradient(90deg,#6ee7b7,#3bd47b)';
        buzzerStatus.style.background = 'rgba(255,255,255,0.06)';
      }
    }

    try { logEl.textContent = JSON.stringify(d, null, 2); }
    catch(e) { logEl.textContent = String(d); }

    const boot = document.getElementById('bootOverlay');
    if (boot && boot.style.display !== 'none') boot.style.display = 'none';
  }

  async function fetchData() {
    try {
      const r = await fetch('/data');
      if (!r.ok) throw new Error('no data');
      const json = await r.json();
      updateFromJson(json);
    } catch(e) {
      console.warn('fetchData err', e);
      connEl.textContent = 'Offline';
    }
  }

  function startSSE() {
    if (typeof EventSource === 'undefined') return false;
    try {
      sse = new EventSource('/stream');
      sse.onopen = () => { connEl.textContent = 'Online (SSE)'; };
      sse.onmessage = evt => {
        try {
          const json = JSON.parse(evt.data);
          updateFromJson(json);
        } catch(e) { console.warn('sse json', e); }
      };
      sse.onerror = () => {
        connEl.textContent = 'SSE error';
        try { sse.close(); } catch(_) {}
        sse = null;
        startPolling();
      };
      return true;
    } catch {
      return false;
    }
  }

  function startPolling() {
    if (polling) return;
    polling = setInterval(fetchData, 1000);
    fetchData();
  }

  async function sendServoEndpoint(path) {
    try {
      const r = await fetch(path);
      return r.ok;
    } catch {
      return false;
    }
  }
  async function setRadarAngle(a) {
    let ok = await sendServoEndpoint(`/servoRadar?angle=${a}`);
    if (!ok) ok = await sendServoEndpoint(`/control?servo=0&angle=${a}`);
    return ok;
  }
  async function setCrane1(a) {
    let ok = await sendServoEndpoint(`/servoCrane1?angle=${a}`);
    if (!ok) ok = await sendServoEndpoint(`/control?servo=1&angle=${a}`);
    return ok;
  }
  async function setCrane2(a) {
    let ok = await sendServoEndpoint(`/servoCrane2?angle=${a}`);
    if (!ok) ok = await sendServoEndpoint(`/control?servo=2&angle=${a}`);
    return ok;
  }

  refreshBtn.onclick = fetchData;
  buzzerTest.onclick = async () => {
    await setRadarAngle(20);
    setTimeout(()=>setRadarAngle(90), 420);
  };

  radarManual.oninput = e => radarManualVal.textContent = e.target.value + '°';
  setRadarBtn.onclick = async () => await setRadarAngle(Number(radarManual.value));
  centerRadarBtn.onclick = async () => { radarManual.value = 90; radarManualVal.textContent = '90°'; await setRadarAngle(90); };

  crane1.oninput = e => c1Val.textContent = e.target.value;
  crane2.oninput = e => c2Val.textContent = e.target.value;
  crane1.onchange = async e => await setCrane1(Number(e.target.value));
  crane2.onchange = async e => await setCrane2(Number(e.target.value));

  c1Load.onclick = async () => { crane1.value = 40; c1Val.textContent = '40'; await setCrane1(40); };
  c1Unload.onclick = async () => { crane1.value = 140; c1Val.textContent = '140'; await setCrane1(140); };
  c2Load.onclick = async () => { crane2.value = 40; c2Val.textContent = '40'; await setCrane2(40); };
  c2Unload.onclick = async () => { crane2.value = 140; c2Val.textContent = '140'; await setCrane2(140); };

  clearLog.onclick = () => logEl.textContent = '';

  setInterval(async () => {
    if (!autoRadar.checked) {
      const v = Number(radarManual.value);
      await setRadarAngle(v);
    }
  }, 400);

  (function bootSim(){
    const p = $('bootProgress');
    let v = 0;
    const t = setInterval(()=>{
      v += Math.floor(Math.random()*12);
      if (v > 100) v = 100;
      p.style.width = v + '%';
      if (v >= 100) clearInterval(t);
    }, 220);
  })();

  if (!startSSE()) startPolling();
  fetchData();

  try { ipEl.textContent = location.hostname; } catch { ipEl.textContent = '--'; }
})();
