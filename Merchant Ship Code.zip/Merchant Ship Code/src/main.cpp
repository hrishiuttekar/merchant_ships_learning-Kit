// main.cpp - Merchant Ship IoT (Adafruit_SSD1306 version)
#include <Arduino.h>
#include <WiFi.h>
#include <WebServer.h>
#include <LittleFS.h>
#include <Wire.h>
#include <ArduinoJson.h>

#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

#include <Adafruit_NeoPixel.h>
#include <DHT.h>
#include <TinyGPSPlus.h>
#include <ESP32Servo.h>
#include <MPU6050_tockn.h>

// ---------- BOOT BITMAPS (from Code1) ----------
const uint8_t shipBitmap[] PROGMEM = {
 0x00,0x00,0x00,0x00,0x00,0x00,
 0x00,0x00,0x00,0x10,0x00,0x00,
 0x00,0x00,0x00,0x38,0x00,0x00,
 0x00,0x00,0x00,0x38,0x00,0x00,
 0x00,0x00,0x00,0x38,0x00,0x00,
 0x00,0x00,0x00,0x38,0x00,0x00,
 0x00,0x00,0x00,0x7C,0x00,0x00,
 0x00,0x00,0x00,0xFE,0x00,0x00,
 0x00,0x00,0x01,0xFF,0x00,0x00,
 0x00,0x00,0x03,0xFF,0x80,0x00,
 0x00,0x00,0x07,0xFF,0xC0,0x00,
 0x00,0x00,0x0F,0xFF,0xE0,0x00,
 0x00,0x00,0x1F,0xFF,0xF0,0x00,
 0x00,0x00,0x3F,0xFF,0xF8,0x00,
 0x7F,0xFF,0xFF,0xFF,0xFF,0xFE,
 0x7F,0xFF,0xFF,0xFF,0xFF,0xFE,
 0x3F,0xFF,0xFF,0xFF,0xFF,0xFC,
 0x1F,0xFF,0xFF,0xFF,0xFF,0xF8,
 0x0F,0xFF,0xFF,0xFF,0xFF,0xF0,
 0x07,0xFF,0xFF,0xFF,0xFF,0xE0,
 0x03,0xFF,0xFF,0xFF,0xFF,0xC0,
 0x01,0xFF,0xFF,0xFF,0xFF,0x80,
 0x00,0xFF,0xFF,0xFF,0xFF,0x00,
 0x00,0x7F,0xFF,0xFF,0xFE,0x00
};

// ---------- CONFIG ----------
#define WIFI_SSID       "10xTC-AP2"
#define WIFI_PASS       "10xTechClub#"

#define SDA_PIN         21
#define SCL_PIN         22
#define TCA_ADDR        0x70

#define CH_OLED1        0
#define CH_OLED2        1
#define CH_MPU          2

#define DHT_ENGINE_PIN  25
#define DHT_OUTER_PIN   26
#define DHTTYPE         DHT11

#define MQ135_PIN       34
#define MOISTURE_PIN    35

#define US_TRIG_PIN     14
#define US_ECHO_PIN     27

// Servos pins (IMPORTANT)
#define SERVO_RADAR_PIN 18  // radar servo (0..180 sweep)
#define SERVO_CRANE1_PIN 19 // crane 1 - manual load/unload
#define SERVO_CRANE2_PIN 23 // crane 2 - manual load/unload

#define NEOPIXEL_PIN    4
#define NEOPIXEL_COUNT  8

#define GPS_RX          16
#define GPS_TX          17
#define GPS_BAUD        9600

#define OLED_ADDR       0x3C

#define BUZZER_PIN      33

#define GAS_ALERT_RAW       1800
#define OILTANK_LEVEL_LOW_PCT 15
#define PROX_ALERT_CM       30

#define RADAR_MIN_ANGLE     0
#define RADAR_MAX_ANGLE     180
#define RADAR_STEP          2
#define RADAR_SWEEP_MS      30

#define SENSOR_INTERVAL_MS  1000
#define OLED_INTERVAL_MS    800
#define GPS_INTERVAL_MS     250
#define STREAM_INTERVAL_MS  500

// ---------- GLOBALS ----------
WebServer server(80);

DHT dht_engine(DHT_ENGINE_PIN, DHTTYPE);
DHT dht_outer(DHT_OUTER_PIN, DHTTYPE);

Adafruit_NeoPixel pixels(NEOPIXEL_COUNT, NEOPIXEL_PIN, NEO_GRB + NEO_KHZ800);

HardwareSerial GPS_Serial(2);
TinyGPSPlus gps;

// Adafruit SSD1306 displays - same I2C address but we switch TCA channel before using init/operations
Adafruit_SSD1306 display1(128, 64, &Wire, -1);
Adafruit_SSD1306 display2(128, 64, &Wire, -1);

MPU6050 mpu(Wire);

Servo servoRadar, servoCrane1, servoCrane2;

// runtime state
float t_engine=0, h_engine=0, t_outer=0, h_outer=0;
uint16_t gas_raw=0, moisture_raw=0;
float oilLevelPct = -1;
float mpu_roll=0, mpu_pitch=0, mpu_yaw=0;
int sats=0;
double lat=0, lon=0;
String gps_time = "-";

volatile int radarAngle = 90; // start centered
int radarDir = +1;
float radarDistanceCm = -1;

int crane1Angle = 90, crane2Angle = 90; // current positions
int targetCrane1 = 90, targetCrane2 = 90; // desired positions (smooth move)

bool alert_gas=false, alert_leak=false, alert_prox=false;

unsigned long lastSensorMs=0, lastRadarMs=0, lastOledMs=0, lastGpsMs=0, lastStreamMs=0;

// SSE client
WiFiClient sseClient;
bool sseActive = false;

// ---------- HELPERS ----------
void tcaselect(uint8_t ch){
  if (ch > 7) return;
  Wire.beginTransmission(TCA_ADDR);
  Wire.write(1 << ch);
  Wire.endTransmission();
  delayMicroseconds(100);
}

float readUltrasonicCm() {
  digitalWrite(US_TRIG_PIN, LOW);
  delayMicroseconds(3);
  digitalWrite(US_TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(US_TRIG_PIN, LOW);
  long dur = pulseIn(US_ECHO_PIN, HIGH, 30000UL);
  if (dur == 0) return -1;
  return dur / 58.0;
}

void setNeoPixelColor(uint8_t r, uint8_t g, uint8_t b) {
  for (int i=0;i<NEOPIXEL_COUNT;i++){
    pixels.setPixelColor(i, pixels.Color(r,g,b));
  }
  pixels.show();
}

String contentTypeFor(const String& path) {
  if (path.endsWith(".html")) return "text/html";
  if (path.endsWith(".css"))  return "text/css";
  if (path.endsWith(".js"))   return "application/javascript";
  if (path.endsWith(".json")) return "application/json";
  if (path.endsWith(".png"))  return "image/png";
  if (path.endsWith(".jpg"))  return "image/jpeg";
  if (path.endsWith(".ico"))  return "image/x-icon";
  return "text/plain";
}

bool serveFile(const String& path) {
  String p = path;
  if (!p.startsWith("/")) p = "/" + p;
  if(!LittleFS.exists(p)) return false;
  File file = LittleFS.open(p, "r");
  if(!file) return false;
  server.streamFile(file, contentTypeFor(p));
  file.close();
  return true;
}

// Helper: draw right aligned text using getTextBounds
void drawRightAligned(Adafruit_SSD1306 &d, int y, const String &s) {
  int16_t x1,y1;
  uint16_t w,h;
  d.getTextBounds(s.c_str(), 0, y, &x1, &y1, &w, &h);
  int16_t x = 127 - (int16_t)w;
  if (x < 0) x = 0;
  d.setCursor(x, y);
  d.print(s);
}

// ---------- BOOT ANIMATION ----------
// Shows the ship bitmap + progress bar on both OLEDs (via tca select)
void showBootAnimation(){
  for (int progress = 0; progress <= 100; progress += 10) {
    int w = map(progress, 0, 100, 0, 100);

    // OLED1
    tcaselect(CH_OLED1);
    display1.clearDisplay();
    display1.setTextSize(1);
    display1.setTextColor(SSD1306_WHITE);
    display1.setCursor(20, 50);
    display1.print("Loading Ship Data");
    display1.drawRect(15, 35, 100, 10, SSD1306_WHITE);
    if (w>0) display1.fillRect(15, 35, w, 10, SSD1306_WHITE);
    // draw ship bitmap (bitmap width 48, height 24)
    display1.drawBitmap(40, 2, shipBitmap, 48, 24, SSD1306_WHITE);
    display1.display();

    // OLED2 (mirror)
    tcaselect(CH_OLED2);
    display2.clearDisplay();
    display2.setTextSize(1);
    display2.setTextColor(SSD1306_WHITE);
    display2.setCursor(12, 50);
    display2.print("Loading Ship Data");
    display2.drawRect(15, 35, 100, 10, SSD1306_WHITE);
    if (w>0) display2.fillRect(15, 35, w, 10, SSD1306_WHITE);
    display2.drawBitmap(40, 2, shipBitmap, 48, 24, SSD1306_WHITE);
    display2.display();

    delay(300);
  }
  delay(600);
}

// ---------- Display updates ----------
void updateDisplays() {
  // OLED1: Engine Room + Oil + Alerts
  tcaselect(CH_OLED1);
  display1.clearDisplay();
  display1.setTextSize(1);
  display1.setTextColor(SSD1306_WHITE);
  display1.setCursor(0, 0);
  display1.print("Engine Room");
  display1.setCursor(0, 12);
  display1.print("T: ");
  display1.print(t_engine,1);
  display1.print("C  H: ");
  display1.print(h_engine,0);
  display1.print("%");
  display1.setCursor(0, 24);
  display1.print("Gas: ");
  display1.print(gas_raw);
  display1.setCursor(0, 36);
  if (oilLevelPct < 0) display1.print("Oil Tank: No fuel");
  else {
    display1.print("Oil Level: ");
    display1.print((int)oilLevelPct);
    display1.print("%");
  }
  String al = String(alert_gas?"GAS ":"") + String(alert_leak?"OILLOW ":"") + String(alert_prox?"PROX ":"");
  if (al.length() == 0) al = "None";
  display1.setCursor(0, 48);
  display1.print("ALERTS: ");
  display1.print(al);

  // right column: Radar
  display1.setTextSize(1);
  drawRightAligned(display1, 0, String("Radar"));
  drawRightAligned(display1, 12, String("Ang: ") + String(radarAngle));
  drawRightAligned(display1, 24, String("Dist: ") + (radarDistanceCm < 0 ? String("-") : String((int)radarDistanceCm) + "cm"));
  display1.display();

  // OLED2: GPS + Outer
  tcaselect(CH_OLED2);
  display2.clearDisplay();
  display2.setTextSize(1);
  display2.setTextColor(SSD1306_WHITE);
  display2.setCursor(0, 0);
  display2.print("GPS: ");
  display2.print(lat, 4);
  display2.print(",");
  display2.print(lon, 4);
  display2.setCursor(0, 10);
  display2.print("Sats:");
  display2.print(sats);
  display2.print(" ");
  display2.print(gps_time);
  display2.setCursor(0, 20);
  display2.print("Out:");
  display2.print(t_outer,1);
  display2.print("C ");
  display2.print(h_outer,0);
  display2.print("%");
  String sys = (alert_gas || alert_leak || alert_prox) ? "ALERT!" : "OK";
  drawRightAligned(display2, 20, sys);
  display2.display();
}

// ---------- sensor & logic ----------
void computeOilLevel() {
  if (moisture_raw > 4000) {
    oilLevelPct = -1;
  } else {
    float inv = (4095.0 - (float)moisture_raw);
    oilLevelPct = (inv / 4095.0) * 100.0;
    if (oilLevelPct < 0) oilLevelPct = 0;
    if (oilLevelPct > 100) oilLevelPct = 100;
  }
  if (oilLevelPct >= 0) alert_leak = (oilLevelPct <= OILTANK_LEVEL_LOW_PCT);
  else alert_leak = false;
}

void updateNeoAndBuzzer() {
  if (alert_gas || alert_leak || alert_prox) {
    setNeoPixelColor(255,0,0);
    digitalWrite(BUZZER_PIN, HIGH);
  } else {
    setNeoPixelColor(0,180,0);
    digitalWrite(BUZZER_PIN, LOW);
  }
}

void readSensors() {
  float te = dht_engine.readTemperature();
  float he = dht_engine.readHumidity();
  float to = dht_outer.readTemperature();
  float ho = dht_outer.readHumidity();

  if (!isnan(te)) t_engine = te;
  if (!isnan(he)) h_engine = he;
  if (!isnan(to)) t_outer = to;
  if (!isnan(ho)) h_outer = ho;

  gas_raw = analogRead(MQ135_PIN);
  moisture_raw = analogRead(MOISTURE_PIN);

  computeOilLevel();

  tcaselect(CH_MPU);
  mpu.update();
  mpu_roll  = mpu.getAngleX();
  mpu_pitch = mpu.getAngleY();
  mpu_yaw   = mpu.getAngleZ();

  alert_prox = (radarDistanceCm > 0 && radarDistanceCm <= PROX_ALERT_CM);
  alert_gas = (gas_raw >= GAS_ALERT_RAW);

  updateNeoAndBuzzer();
}

// Take multiple ultrasonic samples and return median
float readUltrasonicMedianCm(uint8_t samples = 5) {
  float vals[9]; // max 9 samples
  samples = constrain(samples, 1, 9);
  for (uint8_t i = 0; i < samples; i++) {
    vals[i] = readUltrasonicCm();
    delayMicroseconds(200); // small gap
  }
  // sort
  for (uint8_t i = 0; i < samples - 1; i++) {
    for (uint8_t j = i + 1; j < samples; j++) {
      if (vals[j] < vals[i]) {
        float t = vals[i]; vals[i] = vals[j]; vals[j] = t;
      }
    }
  }
  return vals[samples / 2]; // median
}

// Optional moving average buffer
#define RADAR_FILTER_LEN 4
float radarBuf[RADAR_FILTER_LEN];
uint8_t radarBufIdx = 0;
bool radarBufFilled = false;

float filterRadar(float v) {
  if (v < 0) return -1; // invalid
  radarBuf[radarBufIdx++] = v;
  if (radarBufIdx >= RADAR_FILTER_LEN) { radarBufIdx = 0; radarBufFilled = true; }
  int count = radarBufFilled ? RADAR_FILTER_LEN : radarBufIdx;
  float sum = 0; for (int i = 0; i < count; i++) sum += radarBuf[i];
  return sum / count;
}

// ---------- radar sweep ----------
void sweepRadar() {
  unsigned long now = millis();
  if (now - lastRadarMs >= RADAR_SWEEP_MS) {
    lastRadarMs = now;

    // move angle
    radarAngle += radarDir * RADAR_STEP;
    if (radarAngle >= RADAR_MAX_ANGLE) { radarAngle = RADAR_MAX_ANGLE; radarDir = -1; }
    if (radarAngle <= RADAR_MIN_ANGLE) { radarAngle = RADAR_MIN_ANGLE; radarDir = +1; }
    servoRadar.write(radarAngle);

    delay(8); // allow servo to settle slightly

    // read distance with median + filter
    float raw = readUltrasonicMedianCm(3);
    if (raw <= 0 || raw > 350) radarDistanceCm = -1; // out of range
    else radarDistanceCm = filterRadar(raw);
  }
}

// ---------- GPS ----------
void readGPS() {
  while (GPS_Serial.available()) gps.encode(GPS_Serial.read());
  if (gps.location.isValid()) { lat = gps.location.lat(); lon = gps.location.lng(); }
  if (gps.satellites.isValid()) sats = gps.satellites.value();
  if (gps.time.isValid()) {
    char buf[16];
    snprintf(buf, sizeof(buf), "%02d:%02d:%02d",
             gps.time.hour(), gps.time.minute(), gps.time.second());
    gps_time = String(buf);
  }
}

// ---------- smooth servo for cranes ----------
void smoothMoveServo(Servo &servo, int &currentAngle, int target, int step=3) {
  if (currentAngle == target) return;
  if (abs(currentAngle - target) <= step) {
    currentAngle = target;
  } else if (currentAngle < target) currentAngle += step;
  else currentAngle -= step;
  servo.write(currentAngle);
}

// ---------- SSE helpers ----------
void sseInitClient() {
  // nothing here — we accept client in handler and store sseClient
}

void sseSend(const String &payload) {
  if (!sseActive) return;
  if (!sseClient.connected()) {
    sseActive = false;
    sseClient.stop();
    Serial.println("[SSE] Client disconnected");
    return;
  }
  sseClient.print("data: ");
  sseClient.print(payload);
  sseClient.print("\n\n");
  sseClient.flush();
}

// ---------- HTTP handlers ----------
void handleRoot() { if(!serveFile("/index.html")) server.send(404,"text/plain","index.html not found"); }
void handleStatic() {
  String path = server.uri();
  if (!serveFile(path)) server.send(404,"text/plain","not found");
}
void handleFavicon(){ if(!serveFile("/favicon.ico")) server.send(204,"text/plain"," "); }

void handleData() {
  StaticJsonDocument<2048> doc;
  JsonObject eng = doc.createNestedObject("engine_room");
  eng["temp_c"] = t_engine;
  eng["hum_pct"] = h_engine;
  eng["gas_raw"] = gas_raw;
  eng["oil_level_pct"] = (oilLevelPct < 0 ? -1 : (int)oilLevelPct);

  JsonObject outer = doc.createNestedObject("outer");
  outer["temp_c"] = t_outer;
  outer["hum_pct"] = h_outer;

  JsonObject gpsj = doc.createNestedObject("gps");
  gpsj["lat"] = lat; gpsj["lon"] = lon; gpsj["sats"] = sats; gpsj["time"] = gps_time;

  JsonObject radar = doc.createNestedObject("radar");
  radar["angle"] = radarAngle;
  radar["distance_cm"] = (radarDistanceCm < 0 ? -1 : (int)radarDistanceCm);

  JsonObject crane = doc.createNestedObject("crane");
  crane["s1"] = crane1Angle; crane["s2"] = crane2Angle;

  JsonObject alerts = doc.createNestedObject("alerts");
  alerts["gas"] = alert_gas; alerts["oilLow"] = alert_leak; alerts["proximity"] = alert_prox; alerts["any"] = (alert_gas||alert_leak||alert_prox);

  String out; serializeJson(doc, out);
  server.send(200, "application/json", out);
}

void logAndJsonResponse(const char* tag, int servoId, int angle) {
  Serial.printf("[HTTP] %s requested: servo=%d angle=%d\n", tag, servoId, angle);
  StaticJsonDocument<128> doc;
  doc["ok"] = true;
  doc["servo"] = servoId;
  doc["angle"] = angle;
  String out; serializeJson(doc, out);
  server.send(200, "application/json", out);
}

void handleControl() {
  // GET style: /control?servo=1&angle=90
  if (server.method() == HTTP_GET) {
    if (!server.hasArg("servo") || !server.hasArg("angle")) {
      server.send(400,"application/json","{\"ok\":false,\"error\":\"missing servo or angle\"}");
      return;
    }
    int s = server.arg("servo").toInt();
    int a = constrain(server.arg("angle").toInt(), 0, 180);
    if (s==0) {
      // radar — write immediate
      radarAngle = a; servoRadar.write(radarAngle);
      Serial.printf("[CONTROL] radar set immediate to %d\n", radarAngle);
      logAndJsonResponse("control", s, a);
      return;
    } else if (s==1) { targetCrane1 = a; Serial.printf("[CONTROL] set target crane1=%d\n", a); logAndJsonResponse("control", s, a); return;}
    else if (s==2) { targetCrane2 = a; Serial.printf("[CONTROL] set target crane2=%d\n", a); logAndJsonResponse("control", s, a); return;}
    else { server.send(400,"application/json","{\"ok\":false,\"error\":\"servo must be 0/1/2\"}"); return; }
  }

  // POST JSON body { "servo":1,"angle":90 }
  if (server.method() == HTTP_POST) {
    String body = server.arg("plain");
    StaticJsonDocument<256> rdoc;
    DeserializationError err = deserializeJson(rdoc, body);
    if (err) { server.send(400,"application/json","{\"ok\":false,\"error\":\"invalid json\"}"); return; }
    int s = rdoc["servo"] | -1; int a = rdoc["angle"] | -1;
    if (s<0 || a<0) { server.send(400,"application/json","{\"ok\":false,\"error\":\"missing fields\"}"); return; }
    a = constrain(a,0,180);
    if (s==0) { radarAngle = a; servoRadar.write(radarAngle); Serial.printf("[CONTROL POST] radar immediate %d\n", a); logAndJsonResponse("control_post", s, a); return; }
    if (s==1) { targetCrane1 = a; Serial.printf("[CONTROL POST] crane1 target %d\n", a); logAndJsonResponse("control_post", s, a); return; }
    if (s==2) { targetCrane2 = a; Serial.printf("[CONTROL POST] crane2 target %d\n", a); logAndJsonResponse("control_post", s, a); return; }
    server.send(400,"application/json","{\"ok\":false,\"error\":\"invalid servo id\"}");
    return;
  }

  server.send(405,"application/json","{\"ok\":false,\"error\":\"method not allowed\"}");
}

void handleServoRadar() {
  if (!server.hasArg("angle")) { server.send(400,"application/json","{\"ok\":false,\"error\":\"missing angle\"}"); return; }
  int a = constrain(server.arg("angle").toInt(), 0, 180);
  radarAngle = a; servoRadar.write(radarAngle);
  Serial.printf("[HTTP] /servoRadar -> %d\n", a);
  logAndJsonResponse("servoRadar", 0, a);
}

void handleServoCrane1() {
  if (!server.hasArg("angle")) { server.send(400,"application/json","{\"ok\":false,\"error\":\"missing angle\"}"); return; }
  int a = constrain(server.arg("angle").toInt(), 0, 180);
  targetCrane1 = a;
  Serial.printf("[HTTP] /servoCrane1 target -> %d\n", a);
  logAndJsonResponse("servoCrane1", 1, a);
}

void handleServoCrane2() {
  if (!server.hasArg("angle")) { server.send(400,"application/json","{\"ok\":false,\"error\":\"missing angle\"}"); return; }
  int a = constrain(server.arg("angle").toInt(), 0, 180);
  targetCrane2 = a;
  Serial.printf("[HTTP] /servoCrane2 target -> %d\n", a);
  logAndJsonResponse("servoCrane2", 2, a);
}

// compatibility /api/cmd (form style)
void handleApiCmd() {
  Serial.println("[HTTP] /api/cmd called");
  if (server.hasArg("servo") && server.hasArg("angle")) {
    handleControl();
    return;
  }
  // try parse body like servo=1&angle=90
  if (server.method()==HTTP_POST) {
    String b = server.arg("plain");
    int sIndex = b.indexOf("servo=");
    int aIndex = b.indexOf("angle=");
    if (sIndex>=0 && aIndex>=0) {
      int s = b.substring(sIndex+6).toInt();
      int a = b.substring(aIndex+6).toInt();
      if (s==0) { radarAngle=a; servoRadar.write(radarAngle); Serial.printf("[API CMD] radar immediate %d\n", a); }
      else if (s==1) { targetCrane1=a; Serial.printf("[API CMD] crane1 target %d\n", a); }
      else if (s==2) { targetCrane2=a; Serial.printf("[API CMD] crane2 target %d\n", a); }
      StaticJsonDocument<128> doc; doc["ok"]=true; doc["servo"]=s; doc["angle"]=a; String out; serializeJson(doc,out); server.send(200,"application/json",out); return;
    }
  }
  server.send(400,"application/json","{\"ok\":false,\"error\":\"bad request\"}");
}

// /stream SSE handshake
void handleStream() {
  WiFiClient client = server.client();
  if (!client) return;
  // handshake headers
  server.sendHeader("Cache-Control","no-cache");
  server.sendHeader("Content-Type","text/event-stream");
  server.sendHeader("Connection","keep-alive");
  server.send(200, "text/event-stream", ""); // send HTTP headers
  delay(10);
  // store client for periodic pushes
  sseClient = client;
  sseActive = true;
  Serial.println("[SSE] client connected");
}

// debug endpoint
void handleDebug() {
  StaticJsonDocument<512> doc;
  doc["radarAngle"]=radarAngle;
  doc["radarDistanceCm"]=radarDistanceCm;
  doc["crane1Angle"]=crane1Angle; doc["crane1Target"]=targetCrane1;
  doc["crane2Angle"]=crane2Angle; doc["crane2Target"]=targetCrane2;
  doc["alerts"]["gas"]=alert_gas; doc["alerts"]["oilLow"]=alert_leak; doc["alerts"]["prox"]=alert_prox;
  String out; serializeJson(doc,out);
  server.send(200,"application/json",out);
}

// ---------- SETUP ----------
void setup() {
  Serial.begin(115200);
  delay(100);
  Serial.println("\n--- Merchant Ship IoT (Adafruit SSD1306 build) ---");

  pinMode(BUZZER_PIN, OUTPUT);
  digitalWrite(BUZZER_PIN, LOW);

  // I2C
  Wire.begin(SDA_PIN, SCL_PIN);
  Serial.println("I2C started");

  // Displays: initialize each display while its TCA channel is selected
  tcaselect(CH_OLED1);
  if(!display1.begin(SSD1306_SWITCHCAPVCC, OLED_ADDR)) {
    Serial.println("SSD1306 OLED1 init failed");
  } else {
    display1.clearDisplay();
    display1.display();
  }

  tcaselect(CH_OLED2);
  if(!display2.begin(SSD1306_SWITCHCAPVCC, OLED_ADDR)) {
    Serial.println("SSD1306 OLED2 init failed");
  } else {
    display2.clearDisplay();
    display2.display();
  }

  // show boot animation on both displays (uses tcaselect inside)
  showBootAnimation();

  // show brief boot text on OLED1
  tcaselect(CH_OLED1);
  display1.clearDisplay();
  display1.setTextSize(2);
  display1.setTextColor(SSD1306_WHITE);
  display1.setCursor(0,0);
  display1.print("Seabotics");
  display1.setTextSize(1);
  display1.setCursor(0,24);
  display1.print("Booting...");
  display1.display();

  // DHT
  dht_engine.begin(); dht_outer.begin();
  Serial.println("DHTs init");

  // ADC resolution
  analogReadResolution(12);

  // Ultrasonic pins
  pinMode(US_TRIG_PIN, OUTPUT); pinMode(US_ECHO_PIN, INPUT);

  // Servos
  servoRadar.attach(SERVO_RADAR_PIN);
  servoCrane1.attach(SERVO_CRANE1_PIN);
  servoCrane2.attach(SERVO_CRANE2_PIN);
  servoRadar.write(radarAngle);
  servoCrane1.write(crane1Angle);
  servoCrane2.write(crane2Angle);
  Serial.printf("Servos attached (radar:%d, crane1:%d, crane2:%d)\n", SERVO_RADAR_PIN, SERVO_CRANE1_PIN, SERVO_CRANE2_PIN);

  // NeoPixel
  pixels.begin(); pixels.clear(); setNeoPixelColor(0,0,255);

  // GPS
  GPS_Serial.begin(GPS_BAUD, SERIAL_8N1, GPS_RX, GPS_TX);
  Serial.println("GPS started");

  // MPU
  tcaselect(CH_MPU);
  mpu.begin(); delay(300);
  Serial.println("Calibrating MPU... keep steady");
  mpu.calcGyroOffsets(true);
  Serial.println("MPU calibrated");

  // LittleFS
  if (!LittleFS.begin(true)) {
    Serial.println("LittleFS mount failed (files may be missing)");
  } else {
    Serial.println("LittleFS mounted");
  }

  // WiFi
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASS);
  Serial.printf("Connecting to WiFi %s ...", WIFI_SSID);
  int attempts = 0;
  while (WiFi.status() != WL_CONNECTED && attempts < 30) {
    delay(500); Serial.print(".");
    attempts++;
  }
  if (WiFi.status() == WL_CONNECTED) {
    Serial.printf("\nWiFi connected: %s\n", WiFi.localIP().toString().c_str());
    setNeoPixelColor(0,255,0);
  } else {
    Serial.println("\nWiFi failed");
    setNeoPixelColor(255,100,0);
  }

  // HTTP routes
  server.on("/", HTTP_GET, handleRoot);
  server.on("/index.html", HTTP_GET, handleRoot);
  server.on("/style.css", HTTP_GET, handleStatic);
  server.on("/script.js", HTTP_GET, handleStatic);
  server.on("/favicon.ico", HTTP_GET, handleFavicon);
  server.on("/data", HTTP_GET, handleData);
  server.on("/stream", HTTP_GET, handleStream);
  server.on("/control", HTTP_ANY, handleControl);
  server.on("/servoRadar", HTTP_GET, handleServoRadar);
  server.on("/servoCrane1", HTTP_GET, handleServoCrane1);
  server.on("/servoCrane2", HTTP_GET, handleServoCrane2);
  server.on("/api/cmd", HTTP_ANY, handleApiCmd);
  server.on("/debug", HTTP_GET, handleDebug);
  server.onNotFound([](){ server.send(404,"text/plain","Not found"); });
  server.begin();
  Serial.println("HTTP server started");

  // init timers
  lastSensorMs = millis() - SENSOR_INTERVAL_MS;
  lastRadarMs = millis() - RADAR_SWEEP_MS;
  lastOledMs = millis() - OLED_INTERVAL_MS;
  lastGpsMs = millis() - GPS_INTERVAL_MS;
  lastStreamMs = millis() - STREAM_INTERVAL_MS;
}

// ---------- LOOP ----------
void loop() {
  unsigned long now = millis();
  server.handleClient();

  // GPS
  if (now - lastGpsMs >= GPS_INTERVAL_MS) {
    lastGpsMs = now;
    readGPS();
  }

  // Sensors
  if (now - lastSensorMs >= SENSOR_INTERVAL_MS) {
    lastSensorMs = now;
    readSensors();
  }

  // Radar sweep (auto)
  sweepRadar();

  // Smooth crane moves
  smoothMoveServo(servoCrane1, crane1Angle, targetCrane1, 3);
  smoothMoveServo(servoCrane2, crane2Angle, targetCrane2, 3);

  // OLED updates
  if (now - lastOledMs >= OLED_INTERVAL_MS) {
    lastOledMs = now;
    updateDisplays();
  }

  // SSE periodic push (emit /data snapshot)
  if (sseActive && sseClient.connected()) {
    if (now - lastStreamMs >= STREAM_INTERVAL_MS) {
      lastStreamMs = now;
      StaticJsonDocument<1024> doc;
      doc["t_engine"]=t_engine; doc["h_engine"]=h_engine; doc["gas_raw"]=gas_raw; doc["oil_level_pct"]=(oilLevelPct<0?-1:(int)oilLevelPct);
      JsonObject gpsj = doc.createNestedObject("gps"); gpsj["lat"]=lat; gpsj["lon"]=lon; gpsj["sats"]=sats; gpsj["time"]=gps_time;
      JsonObject radar = doc.createNestedObject("radar"); radar["angle"]=radarAngle; radar["distance_cm"]=(radarDistanceCm<0?-1:(int)radarDistanceCm);
      JsonObject alerts = doc.createNestedObject("alerts"); alerts["gas"]=alert_gas; alerts["oilLow"]=alert_leak; alerts["prox"]=alert_prox; alerts["any"]=(alert_gas||alert_leak||alert_prox);
      String out; serializeJson(doc,out);
      sseSend(out);
    }
  } else {
    // if previous client disconnected, reset flag
    if (sseActive && !sseClient.connected()) {
      sseActive = false;
      sseClient.stop();
      Serial.println("[SSE] client lost");
    }
  }

  delay(1);
}
